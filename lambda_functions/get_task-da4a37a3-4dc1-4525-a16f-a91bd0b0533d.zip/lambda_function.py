import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Task_Table')  # 确保表名和实际一致

def lambda_handler(event, context):
    try:
        # 使用 scan 获取所有数据（注意 scan 不适合超大表，但这里足够用）
        response = table.scan()
        items = response.get('Items', [])

        return {
            'statusCode': 200,
            'body': json.dumps(items)
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }


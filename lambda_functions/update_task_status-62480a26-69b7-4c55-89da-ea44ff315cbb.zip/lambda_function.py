# update_task_status.py

import json
import os
import boto3

# ———— 初始化 DynamoDB 表 ————
dynamodb = boto3.resource("dynamodb")
TABLE_NAME = os.environ.get("TASK_TABLE_NAME", "Task_Table")
table = dynamodb.Table(TABLE_NAME)

def lambda_handler(event, context):
    try:
        # —— 1. 解析输入 payload —— 
        raw_body = event.get("body")
        if raw_body:
            # 来自 API Gateway proxy
            payload = json.loads(raw_body)
        else:
            # 在 Lambda 控制台 Test 直接传的 JSON
            payload = event

        # 宽松获取 Task_ID 和 Status
        task_id    = payload.get("Task_ID")    or payload.get("task_id")    or payload.get("id")
        new_status = payload.get("Status")     or payload.get("status")     or payload.get("new_status")

        if not task_id or not new_status:
            raise ValueError("Missing Task_ID or Status in payload")

        # —— 2. 更新 DynamoDB —— 
        result = table.update_item(
            Key={"Task_ID": task_id},
            UpdateExpression="SET #s = :s",
            ExpressionAttributeNames={"#s": "Status"},
            ExpressionAttributeValues={":s": new_status},
            ReturnValues="UPDATED_NEW"              # 返回更新后的属性
        )

        # —— 3. 返回成功 —— 
        return {
            "statusCode": 200,
            "body": json.dumps({
                "Task_ID": task_id,
                "updated": result["Attributes"]
            })
        }

    except Exception as e:
        # 任意异常都返回 500，并把错误信息放到 body.error 里
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
